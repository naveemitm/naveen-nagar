// src/Table.js
import React, { Fragment, useState } from 'react';
import './table.css';

const Table = ({ data, columns, itemsPerPage = 5, deleteInfo, viewInfo, editInfo }) => {
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [currentPage, setCurrentPage] = useState(1);

  // Sorting logic
  const sortedData = [...data].sort((a, b) => {
    if (sortConfig.key) {
      const aValue = a[sortConfig.key];
      const bValue = b[sortConfig.key];
      if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
    }
    return 0;
  });

  // Pagination logic
  const totalPages = Math.ceil(data.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedData = sortedData.slice(startIndex, startIndex + itemsPerPage);

  const handleSort = (columnKey) => {
    let direction = 'asc';
    if (sortConfig.key === columnKey && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key: columnKey, direction });
  };

  const handleEdit = (columnKey) => {
    editInfo(columnKey);
  };

  const handleView = (columnKey) => {
    viewInfo(columnKey);
  };

  const handleDelete = (columnKey) => {
    //console.log("columnKey",columnKey);
    deleteInfo(columnKey);
  };

  const goToNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const goToPreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  return (
    <div>
      <table className="custom-table">
        <thead>
          <tr>
            {columns.map((column) => (
              <th
                key={column.key}
                onClick={() => handleSort(column.key)}
                className={sortConfig.key === column.key ? sortConfig.direction : ''}
              >
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {paginatedData.map((row, index) => (
            <tr key={index}>
              {columns.map((column) => (
                <td key={column.key}>{column.key=='action' ? 
                  <Fragment>
                  <button style={{marginRight:"10px"}} onClick={() => handleView(row.id)}>
                    View
                  </button>
                  <button style={{marginRight:"10px"}} onClick={() => handleEdit(row.id)}>
                   Edit
                 </button>
                  <button style={{marginRight:"10px"}} onClick={() => handleDelete(row.id)}>
                   Delete
                 </button>
                  </Fragment>
                 
                  : row[column.key]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="pagination-controls">
        <button onClick={goToPreviousPage} disabled={currentPage === 1}>
          Previous
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button onClick={goToNextPage} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>
    </div>
  );
};

export default Table;
