import { setupWorker, rest } from 'msw';

let tasks = [
  { id: 1, title: 'Sample Task 1' },
  { id: 2, title: 'Sample Task 2' },
];

export const handlers = [
  rest.get('/api/tasks', (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(tasks));
  }),

  rest.post('/api/tasks', (req, res, ctx) => {
    const newTask = { id: Date.now(), ...req.body };
    tasks.push(newTask);
    return res(ctx.status(201), ctx.json(newTask));
  }),

  rest.put('/api/tasks/:id', (req, res, ctx) => {
    const { id } = req.params;
    const updatedTask = req.body;
    tasks = tasks.map((task) => (task.id === Number(id) ? updatedTask : task));
    return res(ctx.status(200), ctx.json(updatedTask));
  }),

  rest.delete('/api/tasks/:id', (req, res, ctx) => {
    const { id } = req.params;
    tasks = tasks.filter((task) => task.id !== Number(id));
    return res(ctx.status(200), ctx.json({ id: Number(id) }));
  }),
];

export const worker = setupWorker(...handlers);
