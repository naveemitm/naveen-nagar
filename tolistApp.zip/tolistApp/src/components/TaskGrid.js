import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeTask, getTasks } from '../redux/tasksSlice';
import { Box, Grid, Paper, IconButton, Typography } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';

const TaskGrid = ({ onEdit }) => {
  const { tasks, loading } = useSelector((state) => state.tasks);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getTasks());
  }, [dispatch]);

  const handleDelete = (id) => {
    dispatch(removeTask(id));
  };

  return (
    <Grid container spacing={2}>
      {loading ? (
        <Typography>Loading...</Typography>
      ) : (
        tasks.map((task) => (
          <Grid item xs={12} sm={6} md={4} key={task.id}>
            <Paper sx={{ padding: 2, position: 'relative' }}>
              <Typography variant="h6">{task.title}</Typography>
              <Box sx={{ position: 'absolute', top: 8, right: 8 }}>
                <IconButton color="primary" onClick={() => onEdit(task)}>
                  <EditIcon />
                </IconButton>
                <IconButton color="secondary" onClick={() => handleDelete(task.id)}>
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Paper>
          </Grid>
        ))
      )}
    </Grid>
  );
};

export default TaskGrid;
