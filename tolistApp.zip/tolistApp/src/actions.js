// src/actions.js
import axios from 'axios';

export const FETCH_ITEMS_REQUEST = 'FETCH_ITEMS_REQUEST';
export const FETCH_ITEMS_SUCCESS = 'FETCH_ITEMS_SUCCESS';
export const FETCH_ITEMS_FAILURE = 'FETCH_ITEMS_FAILURE';
export const SET_SEARCH_TERM = 'SET_SEARCH_TERM';
export const SET_SORT_ORDER = 'SET_SORT_ORDER';

export const fetchItemsRequest = () => ({ type: FETCH_ITEMS_REQUEST });
export const fetchItemsSuccess = (items) => ({ type: FETCH_ITEMS_SUCCESS, payload: items });
export const fetchItemsFailure = (error) => ({ type: FETCH_ITEMS_FAILURE, payload: error });

export const setSearchTerm = (term) => ({ type: SET_SEARCH_TERM, payload: term });
export const setSortOrder = (order) => ({ type: SET_SORT_ORDER, payload: order });

export const fetchItems = () => {
  return async (dispatch) => {
    dispatch(fetchItemsRequest());
    try {
      const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
      dispatch(fetchItemsSuccess(response.data));
    } catch (error) {
      dispatch(fetchItemsFailure(error.message));
    }
  };
};
