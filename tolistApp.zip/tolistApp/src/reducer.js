// src/reducer.js
import {
    FETCH_ITEMS_REQUEST,
    FETCH_ITEMS_SUCCESS,
    FETCH_ITEMS_FAILURE,
    SET_SEARCH_TERM,
    SET_SORT_ORDER,
    SET_DELET_INFO,
    UPDATE_INFO
  } from './actions';
  
  const initialState = {
    items: [],
    loading: false,
    error: null,
    searchTerm: '',
    sortOrder: 'asc', // 'asc' for ascending, 'desc' for descending
  };
  
  const itemsReducer = (state = initialState, action) => {
    switch (action.type) {
      case FETCH_ITEMS_REQUEST:
        return { ...state, loading: true, error: null };
      case FETCH_ITEMS_SUCCESS:
        return { ...state, loading: false, items: action.payload };
      case FETCH_ITEMS_FAILURE:
        return { ...state, loading: false, error: action.payload };
      case SET_SEARCH_TERM:
        return { ...state, searchTerm: action.payload };
      case SET_SORT_ORDER:
        return { ...state, sortOrder: action.payload };
      case SET_DELET_INFO:
        let curr_state = { ...state};
        let filter = curr_state.items.filter(list=>list.id!=action.payload);
        return { ...state, items:filter,loading: true, error: null };
      case UPDATE_INFO:
       // let currstate = { ...state};
       // let objIndex = currstate.items.findIndex(obj => obj.id == action.payload.id);
        //currstate.items[objIndex].title = action.payload.title;
        //currstate.items[objIndex].status = action.payload.status;
       return { ...state, items:action.payload,loading: true, error: null };
      default:
        return state;
    }
  };
  
  export default itemsReducer;
  