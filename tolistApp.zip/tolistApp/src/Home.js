// src/Home.js
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchItems, setSearchTerm, setSortOrder,setDeleteInfo } from './actions';
import { useNavigate } from 'react-router-dom';
import Table from './table';
const Home = () => {
  const { items, loading, error, searchTerm, sortOrder } = useSelector((state) => state);
 
  const dispatch = useDispatch();
  const navigate = useNavigate();
  useEffect(() => {
    if(items && items.length==0) {
      dispatch(fetchItems());
    }
   
  }, [dispatch]);

  const columns = [
    { key: 'id', label: 'ID' },
    { key: 'title', label: 'Title' },
    { key: 'status', label: 'Status' },
    { key: 'action', label: 'Action' },
  ];

  const filteredItems = items
    .filter((item) =>
      item.title.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortOrder === 'asc') {
        return a.title.localeCompare(b.title);
      } else {
        return b.title.localeCompare(a.title);
      }
    });

  const handleSearchChange = (e) => {
    console.log("e.target.value",e.target.value);
    dispatch(setSearchTerm(e.target.value.toString()));
  };

  const deleteInfo = (e) => {
    console.log("deleteInfo",e);
    dispatch(setDeleteInfo(e));
  };

  const viewInfo = (e) => {
    console.log("viewInfo",e);
    navigate(`/view/${e}`);
    //dispatch(setSearchTerm(e.target.value.toString()));
  };

  const editInfo = (e) => {
    console.log("editInfo",e);
    navigate(`/edit/${e}`);
    //dispatch(setSearchTerm(e.target.value.toString()));
  };
  
  const handleAdd = () => {
    console.log("addInfo");
    navigate(`/add`);
    //dispatch(setSearchTerm(e.target.value.toString()));
  };
  

  const toggleSortOrder = () => {
    dispatch(setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc'));
  };

  return (
    <div style={{ textAlign: 'center' }}>
         
      {error && <p>Error: {error}</p>}
      <input
        type="text"
        placeholder="Search items..."
        value={searchTerm}
        onChange={handleSearchChange}
      />
     {/*  <h1>Home - Search and Sort</h1>
      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      <input
        type="text"
        placeholder="Search items..."
        value={searchTerm}
        onChange={handleSearchChange}
      />
      <button onClick={toggleSortOrder}>
        Sort {sortOrder === 'asc' ? 'Descending' : 'Ascending'}
      </button>
      <ul>
        {filteredItems.map((item) => (
          <li key={item.id}>{item.title}</li>
        ))}
      </ul> */}
      <div>
      <button style={{marginRight:"10px",marginTop:"20px", marginBottom: "20px",marginRight:"90%"}} onClick={() => handleAdd()}>
         Add New Item
       </button>
      </div>
        
     <Table data={filteredItems} deleteInfo={deleteInfo} viewInfo={viewInfo} editInfo={editInfo} columns={columns} />

   
    </div>
  );
};

export default Home;
