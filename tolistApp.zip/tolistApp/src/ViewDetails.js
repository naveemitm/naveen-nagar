// src/About.js
import React from 'react';
import { useParams } from "react-router-dom";
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import './table.css';
const ViewDetails = () => {
    const { id } = useParams();
    const { items, loading, error, searchTerm, sortOrder } = useSelector((state) => state);
    const navigate = useNavigate();
    const filter = items.filter(list=>list.id==id);
    console.log("items",filter);

    const handleBack = () => {
        navigate(`/`);
        //dispatch(setSearchTerm(e.target.value.toString()));
      };

  return (
    <div style={{ textAlign: 'center' }}>
      <h1>View Details Page : {id}</h1>

      <table className="custom-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
         <tr>
            <td>{filter[0].title}</td>
            <td>{filter[0].status}</td>
         </tr>
        </tbody>
      </table>
      <button style={{marginRight:"10px",marginTop:"20px",marginRight:"95%"}} onClick={() => handleBack()}>
         Cancel
       </button>
      
    </div>
  );
};

export default ViewDetails;