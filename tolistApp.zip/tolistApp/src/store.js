// src/store.js
import { createStore, applyMiddleware } from 'redux';
import { thunk } from 'redux-thunk'; // Corrected import
import itemsReducer from './reducer';

const store = createStore(itemsReducer, applyMiddleware(thunk));

export default store;
