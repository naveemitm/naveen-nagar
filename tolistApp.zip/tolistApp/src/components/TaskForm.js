import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { addNewTask, editTask } from '../redux/tasksSlice';
import { TextField, Button, Box } from '@mui/material';

const TaskForm = ({ taskToEdit, clearEdit }) => {
  const [title, setTitle] = useState('');
  const dispatch = useDispatch();

  useEffect(() => {
    if (taskToEdit) {
      setTitle(taskToEdit.title);
    }
  }, [taskToEdit]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (taskToEdit) {
      dispatch(editTask({ id: taskToEdit.id, title }));
      clearEdit();
    } else {
      dispatch(addNewTask({ title }));
    }
    setTitle('');
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', gap: 2, mb: 2 }}>
      <TextField
        label="Task Title"
        variant="outlined"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        fullWidth
      />
      <Button type="submit" variant="contained" color="primary">
        {taskToEdit ? 'Update' : 'Add'}
      </Button>
    </Box>
  );
};

export default TaskForm;
