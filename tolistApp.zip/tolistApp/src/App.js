// src/App.js
import React from 'react';
import { Route, Routes, Link } from 'react-router-dom';
import Home from './Home';
import About from './About';
import ViewDetails from './ViewDetails';
import EditDetails from './EditDetails';
import AddDetails from './AddDetails';
import './styles/index.scss';

const App = () => {
  return (
    <div className="container">
      <nav>
        <Link to="/" style={{ marginRight: '10px' }}>Home</Link>
        <Link to="/about">About</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/view/:id" element={<ViewDetails />} />
        <Route path="/edit/:id" element={<EditDetails />} />
        <Route path="/add" element={<AddDetails />} />
      </Routes>
    </div>
  );
};

export default App;
