// src/About.js
import React, { useState, useEffect } from 'react';
import { useParams } from "react-router-dom";
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { updateInfo } from './actions';
import './table.css';
const EditDetails = () => {
    const { id } = useParams();
    const { items, loading, error, searchTerm, sortOrder } = useSelector((state) => state);
    const [title, setTitle] = useState('');
    const [status, setStatus] = useState('');
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const options = [{id: 1,value:'todo',label:'To Do'}, {id: 2,value:'inprogress',label:'In Progress'}, {id: 3,value:'completed',label:'Completed'}];
  

      useEffect(() => {
        const filter = items.filter(list=>list.id==id);
        
        setTitle(filter[0].title);
        setStatus(filter[0].status);
    }, []);

    const handleBack = () => {
        navigate(`/`);
        //dispatch(setSearchTerm(e.target.value.toString()));
      };
      const handleSubmit = (e) => {
        e.preventDefault();
        let updatedInfo = [...items];
        console.log("title",updatedInfo);
        //console.log("status",status);
        
        let objIndex = items.findIndex(obj => obj.id == id);
        updatedInfo[objIndex].title = title;
        updatedInfo[objIndex].status = status;
        dispatch(updateInfo(updatedInfo));
        navigate(`/`);
      };
  return (
    <div style={{ textAlign: 'center' }}>
      <h1>Edit Details Page : {id}</h1>

      <table className="custom-table">
       
        <tbody>
         <tr>
            <td>Title:</td>
            <td>
                
                <input
                    type="text"
                    placeholder="title.."
                    style={{width:'50%'}}
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                />
            </td>
         </tr>
         <tr>
            <td>Status:</td>
            <td>
            
            <select onChange={(e) => setStatus(e.target.value)}>
                {options.map(item => (
                    <option 
                    key={item.id} 
                    value={item.value}
                    selected={item.value === status}
                    >{item.label}</option>
                ))}
                </select>
            </td>
         </tr>
        </tbody>
      </table>
      <button style={{marginRight:"10px",marginTop:"20px",marginRight:"20%"}} onClick={handleSubmit}>
         Submit
       </button>
      <button style={{marginRight:"10px",marginTop:"20px",marginRight:"20%"}} onClick={() => handleBack()}>
         Cancel
       </button>
      
    </div>
  );
};

export default EditDetails;