// src/About.js
import React from 'react';

const About = () => {
  return (
    <div style={{ textAlign: 'center' }}>
      <h1>About Page</h1>
      <p>This is a simple app demonstrating Redux and React Router in a React app.</p>
    </div>
  );
};

export default About;
