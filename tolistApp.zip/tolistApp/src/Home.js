// src/Home.js
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchItems, setSearchTerm, setSortOrder } from './actions';
import Table from './table';
const Home = () => {
  const { items, loading, error, searchTerm, sortOrder } = useSelector((state) => state);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchItems());
  }, [dispatch]);

  const columns = [
    { key: 'id', label: 'ID' },
    { key: 'userId', label: 'UserId' },
    { key: 'title', label: 'Title' },
    { key: 'body', label: 'Body' },
  ];

  const filteredItems = items
    .filter((item) =>
      item.title.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortOrder === 'asc') {
        return a.title.localeCompare(b.title);
      } else {
        return b.title.localeCompare(a.title);
      }
    });

  const handleSearchChange = (e) => {
    console.log("e.target.value",e.target.value);
    dispatch(setSearchTerm(e.target.value.toString()));
  };

  const toggleSortOrder = () => {
    dispatch(setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc'));
  };

  return (
    <div style={{ textAlign: 'center' }}>
         {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      <input
        type="text"
        placeholder="Search items..."
        value={searchTerm}
        onChange={handleSearchChange}
      />
     {/*  <h1>Home - Search and Sort</h1>
      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      <input
        type="text"
        placeholder="Search items..."
        value={searchTerm}
        onChange={handleSearchChange}
      />
      <button onClick={toggleSortOrder}>
        Sort {sortOrder === 'asc' ? 'Descending' : 'Ascending'}
      </button>
      <ul>
        {filteredItems.map((item) => (
          <li key={item.id}>{item.title}</li>
        ))}
      </ul> */}
     <Table data={filteredItems} columns={columns} />
    </div>
  );
};

export default Home;
