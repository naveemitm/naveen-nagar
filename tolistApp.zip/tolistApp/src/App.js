import React, { useState } from 'react';
import TaskForm from './components/TaskForm';
import TaskGrid from './components/TaskGrid';
import { Container, Typography } from '@mui/material';

const App = () => {
  const [taskToEdit, setTaskToEdit] = useState(null);

  const handleEdit = (task) => {
    setTaskToEdit(task);
  };

  const clearEdit = () => {
    setTaskToEdit(null);
  };

  return (
    <Container>
      <Typography variant="h4" align="center" sx={{ my: 4 }}>
        Task Management Dashboard
      </Typography>
      <TaskForm taskToEdit={taskToEdit} clearEdit={clearEdit} />
      <TaskGrid onEdit={handleEdit} />
    </Container>
  );
};

export default App;
